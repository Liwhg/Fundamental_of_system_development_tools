import sys

import pytest

from greetlab.cli import main


def test_blank_name_exits_with_code_2(monkeypatch):
    monkeypatch.setattr(sys, "argv", ["sdt-greet", "--name", " "])

    with pytest.raises(SystemExit) as exc_info:
        main()

    assert exc_info.value.code == 2


def test_normal_name_prints_greeting(monkeypatch, capsys):
    monkeypatch.setattr(sys, "argv", ["sdt-greet", "--name", "Ada"])

    main()

    assert capsys.readouterr().out == "Hello, Ada!\n"
